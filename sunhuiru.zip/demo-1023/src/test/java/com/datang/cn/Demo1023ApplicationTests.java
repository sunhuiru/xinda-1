package com.datang.cn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo1023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
