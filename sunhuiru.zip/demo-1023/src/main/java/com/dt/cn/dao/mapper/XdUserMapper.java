package com.dt.cn.dao.mapper;


import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.dt.cn.model.User.XdUser;
import com.dt.cn.model.User.XdUserExample;
@Mapper
public interface XdUserMapper {
    long countByExample(XdUserExample example);

    int deleteByExample(XdUserExample example);

    int deleteByPrimaryKey(String id);

    int insert(XdUser record);

    int insertSelective(XdUser record);

    List<XdUser> selectByExample(XdUserExample example);

    XdUser selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") XdUser record, @Param("example") XdUserExample example);

    int updateByExample(@Param("record") XdUser record, @Param("example") XdUserExample example);

    int updateByPrimaryKeySelective(XdUser record);

    int updateByPrimaryKey(XdUser record);
    int getCount(@Param("name") String name);

   
    
   

	List<XdUser> selectByName(XdUserExample xdUserExample);
}