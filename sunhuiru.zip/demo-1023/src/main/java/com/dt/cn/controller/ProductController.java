package com.dt.cn.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dt.cn.model.User.ProviderProdut;
import com.dt.cn.service.ProductService;



@Controller
@RequestMapping
public class ProductController {

	@Resource
	ProductService productService;

	@RequestMapping("/serviceProduct")
	public String serviceProduct() {

		return "service_product";

	}

	@RequestMapping("/serviceOrderform")
	public String serviceOrderform() {

		return "service_orderform";

	}

	@RequestMapping("/serviceExpenses")
	public String serviceExpenses() {

		return "service_expenses";

	}

	@RequestMapping("/serviceStore")
	public String serviceStore() {

		return "service_store";

	}

	@RequestMapping("/serviceSetting")
	public String serviceSetting() {

		return "service_setting";

	}

	@RequestMapping("/selectByName")
	public String selectByExample(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "3") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
		List<ProviderProdut> providerprodutList = productService.selectByName(pageStart, pageSize, servicename);
		long count = 0;

		if (servicename.equals("") || servicename == null)
			count = productService.getCount();
		else
			count = productService.getCount(servicename);
		map.put("count", count);
		map.put("providerprodutList", providerprodutList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		return "service_product";
	}

	@RequestMapping("/delete")
	public ModelAndView selectByExample(Map<String, Object> map,
			@RequestParam(defaultValue = "0", required = false) Integer id) {
		int i = productService.deleteByPrimaryKey(id);
		if (i == 1)
			return new ModelAndView("redirect:/selectByName");
		else
			return new ModelAndView("error");
	}

	@RequestMapping("/insert")
	public String insert(ProviderProdut providerProdut) {
		int i = productService.insert(providerProdut);
		if (i == 1)
			return "redirect:/selectByName";
		else
			return "error";

	}

	@RequestMapping("/update")
	public String update(ProviderProdut providerProdut) {
		int i = productService.updateByPrimaryKey(providerProdut);
		if (i == 1)
			return "redirect:/selectByName";
		else
			return "error";

	}

	@RequestMapping("/updateQ")
	public String updateQ(Integer id, Model model) throws Exception {

		ProviderProdut providerprodutList = productService.selectByPrimaryKey(id);
		model.addAttribute("providerprodutList", providerprodutList);
		return "service_update";
	}

}
