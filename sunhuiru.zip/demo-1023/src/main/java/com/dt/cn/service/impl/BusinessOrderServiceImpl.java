package com.dt.cn.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dt.cn.dao.mapper.BusinessOrderMapper;
import com.dt.cn.model.User.BusinessOrder;
import com.dt.cn.model.User.BusinessOrderExample;
import com.dt.cn.service.BusinessOrderService;

@Service  //声明服务层
public class BusinessOrderServiceImpl implements BusinessOrderService{
	@Resource //对象初始化一般在dao
	BusinessOrderMapper businessOrderMapper;
	@Override
	public List<BusinessOrder> selectByNumber(int pageStart, int pageSize, String number) {
		BusinessOrderExample  businessorderExample=new BusinessOrderExample();
		businessorderExample.setDistinct(true);
		businessorderExample.setPageStart(pageStart);
		businessorderExample.setPageSize(pageSize);
		businessorderExample.setNumber(number);
		return businessOrderMapper.selectByNumber(businessorderExample);
	}
		@Override
	public long getCount() {
			BusinessOrderExample  businessorderExample=new BusinessOrderExample();
		return businessOrderMapper.countByExample(businessorderExample);
	}
		@Override
		public int getCount(String number) {
			
			return  businessOrderMapper.getCount(number);
		}
		@Override
		public int deleteByPrimaryKey(String businessNo) {
			
			return businessOrderMapper.deleteByPrimaryKey(businessNo);
		}
		
	

	}


