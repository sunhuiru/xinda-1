package com.dt.cn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.dt.cn.*")
public class Demo1023Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo1023Application.class, args);
	}

}
