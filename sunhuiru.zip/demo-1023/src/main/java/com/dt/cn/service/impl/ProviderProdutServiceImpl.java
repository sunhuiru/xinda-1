package com.dt.cn.service.impl;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dt.cn.dao.mapper.CartMapper;
import com.dt.cn.dao.mapper.ProviderProdutMapper;
import com.dt.cn.model.User.Cart;
import com.dt.cn.model.User.CartExample;
import com.dt.cn.model.User.ProviderProdut;
import com.dt.cn.model.User.ProviderProdutExample;
import com.dt.cn.service.ProviderProdutService;


@Service
public class ProviderProdutServiceImpl implements ProviderProdutService{
	@Resource
    ProviderProdutMapper providerProdutMapper;
	@Resource
	CartMapper cartMapper;
	@Override
	public List<ProviderProdut> selectByExample(int pageStart, int pageSize) {
		ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		providerProdutExample.setDistinct(true);
		providerProdutExample.setPageStart(pageStart);
		providerProdutExample.setPageSize(pageSize);
		//System.out.println("pageStart"+pageStart);
		return providerProdutMapper.selectByExample(providerProdutExample);
	}
	@Override
	public long getCount() {
		ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		return providerProdutMapper.countByExample(providerProdutExample);
	}
	@Override
	public int getCount(String servicename) {
		return providerProdutMapper.getCount(servicename);
	}
	@Override
	public List<ProviderProdut> selectByName(int pageStart, int pageSize, String servicename) {
		ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		providerProdutExample.setDistinct(true);
		providerProdutExample.setPageStart(pageStart);
		providerProdutExample.setPageSize(pageSize);
		providerProdutExample.setServicename(servicename);
		return providerProdutMapper.selectByName(providerProdutExample);
	}
	@Override                                   
	public int updataImg(ProviderProdut produt) {
		// TODO Auto-generated method stub
		return providerProdutMapper.updateById(produt);
	}
	@Override
	public int insertSelective(Cart record) {	
		//System.out.println("aaaaaaaaaaa"+record.getId());
		return cartMapper.insertSelective(record);
	}
	@Override
	public ProviderProdut getProviderProdutById(String id) {
		/*ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		ProviderProdutExample.Criteria criteria=providerProdutExample.createCriteria();
		criteria.andIdEqualTo(id);
		return null;*/
		return providerProdutMapper.selectByPrimaryKey(id);
	}
	@Override
	public ProviderProdut selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return providerProdutMapper.selectByPrimaryKey(id);
	}
	@Override
	public long getCount1() {
		CartExample cartExample=new CartExample();
		return cartMapper.countByExample1(cartExample);
	}
	@Override
	public int getCount1(String servicename) {
	
		return cartMapper.getCount1(servicename);
	}
	@Override
	public List<Cart> selectByName1(int pageStart, int pageSize, String servicename) {
		CartExample cartExample=new CartExample();
		cartExample.setDistinct(true);
		cartExample.setPageSize(pageSize);
		cartExample.setPageStart(pageStart);
		cartExample.setServicename(servicename);
		return cartMapper.selectByName1(cartExample);
	}
	@Override
	public int deleteByPrimaryKey(String id) {		
		return cartMapper.deleteByPrimaryKey(id);
	}
	@Override
	public int selectTotalPriceById(String productId) {
		// TODO Auto-generated method stub
		return cartMapper.selectTotalPriceById(productId);
	}
	@Override
	public int updateNumAndPriceByProductId(String productId,int buynum,int totalprice) {
		// TODO Auto-generated method stub
		return cartMapper.updateNumAndPriceByProductId(productId,buynum,totalprice);
	}
	@Override
	public int selectUnitPriceById(String productId) {
		// TODO Auto-generated method stub
		//System.out.println(productId);
		return cartMapper.selectUnitPriceById(productId);
	}
}
