package com.dt.cn.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.dt.cn.model.User.BusinessOrder;
import com.dt.cn.model.User.BusinessOrderExample;

public interface BusinessOrderService {
	List<BusinessOrder> selectByNumber(int pageStart ,int pageSize,String number);

	int getCount(@Param("number") String number);

   long getCount();
   
   int deleteByPrimaryKey(String businessNo);
}
