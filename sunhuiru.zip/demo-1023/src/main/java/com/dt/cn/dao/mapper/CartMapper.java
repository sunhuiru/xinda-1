package com.dt.cn.dao.mapper;



import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.dt.cn.model.User.Cart;
import com.dt.cn.model.User.CartExample;

@Mapper
public interface CartMapper {
	long countByExample1(CartExample example);

	int deleteByExample(CartExample example);

	int deleteByPrimaryKey(String id);

	int insert(Cart record);

	int insertSelective(Cart record);

	List<Cart> selectByExample(CartExample example);

	Cart selectByPrimaryKey(String id);

	int updateByExampleSelective(@Param("record") Cart record, @Param("example") CartExample example);

	int updateByExample(@Param("record") Cart record, @Param("example") CartExample example);

	int updateByPrimaryKeySelective(Cart record);

	int updateByPrimaryKey(Cart record);

	int getCount1(@Param("servicename") String servicename);

	List<Cart> selectByName1(int pageStart, int pageSize, String servicename);

	List<Cart> selectByName1(CartExample cartExample);

	int selectTotalPriceById(String productId);

	int updateNumAndPriceByProductId(String productId, int buynum, int totalPrice);

	int selectUnitPriceById(String productId);
}