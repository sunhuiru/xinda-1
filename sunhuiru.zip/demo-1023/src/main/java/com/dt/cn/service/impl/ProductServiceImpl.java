package com.dt.cn.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dt.cn.dao.mapper.ProviderProdutMapper;
import com.dt.cn.model.User.ProviderProdut;
import com.dt.cn.model.User.ProviderProdutExample;
import com.dt.cn.service.ProductService;



@Service
public class ProductServiceImpl implements ProductService{

	@Resource
	ProviderProdutMapper providerProdutMapper;

	@Override
	public long getCount() {
		ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		return providerProdutMapper.countByExample(providerProdutExample);
	}

	@Override
	public int getCount(String servicename) {
		return providerProdutMapper.getCount(servicename);
	}

	@Override
	public List<ProviderProdut> selectByName(int pageStart, int pageSize, String servicename) {
		ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		providerProdutExample.setDistinct(true);
		providerProdutExample.setPageStart(pageStart);
		providerProdutExample.setPageSize(pageSize);
		providerProdutExample.setServicename(servicename);
		return providerProdutMapper.selectByName(providerProdutExample);
	}

	@Override
	public int deleteByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		return providerProdutMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(ProviderProdut record) {
		/* record.setId(12); */
		// TODO Auto-generated method stub
		return providerProdutMapper.insert(record);
	}

	@Override
	public int updateByPrimaryKey(ProviderProdut record) {
		// TODO Auto-generated method stub
		return providerProdutMapper.updateByPrimaryKey(record);
	}

	@Override
	public ProviderProdut selectByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		return providerProdutMapper.selectByPrimaryKey(id);
	}

	

}
