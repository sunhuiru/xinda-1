package com.dt.cn.controller;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.dt.cn.model.User.Cart;
import com.dt.cn.model.User.ProviderProdut;
import com.dt.cn.service.ProviderProdutService;


@Controller
public class ControllerProviderProdut {
	@Resource
	ProviderProdutService providerProdutService;
	@RequestMapping("/providerprodutfenye")
	public String providerProdutFenYe(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "1") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
		// System.out.println("aaaaaaaaaaaa");
		List<ProviderProdut> providerprodutList = providerProdutService.selectByName(pageStart, pageSize, servicename);
		long count = 0;
		if (servicename.equals("") || servicename == null)
			count = providerProdutService.getCount();
		else
			count = providerProdutService.getCount(servicename);
		map.put("providerprodutList", providerprodutList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		map.put("count", count);
		// System.out.println("count="+count);
		return "e-commerce_product";
	}

	@RequestMapping("/loadimg")
	public String loadImg() {
		return "upfile";
	}

	@RequestMapping("/upfile")
	public String saveUserImg(MultipartFile file) {
		Map<Object, Object> result = new HashMap<Object, Object>();
		try {
			// 获取客户端传图图片的输入流
			InputStream ins = file.getInputStream();
			byte[] buffer = new byte[8192];// bit---byte---1k---1m
			int len = 0;
			// 字节输出流
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			while ((len = ins.read(buffer)) != -1) {
				bos.write(buffer, 0, len);
			}
			bos.flush();
			byte data[] = bos.toByteArray();
			System.out.println(data);
			ProviderProdut produt = new ProviderProdut();
			produt.setId("00006");
			produt.setImg(data);
			providerProdutService.updataImg(produt);
			// System.out.println("aaaaaaaaaaaa");
			result.put("code", 1);
			result.put("msg", "保存头像成功");
		} catch (Exception e) {
			result.put("code", 0);
			result.put("msg", "保存头像失败");
			return "uploaderror";
		}
		return "index";
	}

	@RequestMapping(value = "/headImg", produces = MediaType.IMAGE_PNG_VALUE)
	public ResponseEntity<byte[]> headImg(String id) throws Exception {

		byte[] imageContent;
		ProviderProdut produt = providerProdutService.selectByPrimaryKey(id);
		imageContent = produt.getImg();
		// System.out.println("图片==="+produt.getImg());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.IMAGE_PNG);
		return new ResponseEntity<byte[]>(imageContent, headers, HttpStatus.OK);
	}

	@RequestMapping("/insertCart")
	public String getById(Model model, @RequestParam(required = true) String id) {
		// System.out.println("id=:"+id);
		ProviderProdut providerProdut = providerProdutService.getProviderProdutById(id);
		// System.out.println(providerProdut.getId());
		model.addAttribute("providerProdut", providerProdut);
		Cart cart = new Cart();
		cart.setId(providerProdut.getId());
		cart.setProvideId(providerProdut.getId());
		cart.setUnitPrice(providerProdut.getPrice());
		cart.setServiceName(providerProdut.getServiceName());
		cart.setImg(providerProdut.getImg());
		cart.setMemberId("22222");
		cart.setBuyNum(1);
		cart.setProvideId("111");
		cart.setServiceInfo("5555");
		cart.setServiceRequest("2222");
		cart.setTotalPrice(456);
		cart.setUnit("1");
		int code = providerProdutService.insertSelective(cart);
		// System.out.println("price="+providerProdut.getPrice());
		return code == 1 ? "redirect:cartfenye" : "error";
	}

	@RequestMapping("/cartfenye")
	public String cartFenYe(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "1") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
//System.out.println("aaaaaaaaaaaa");
		List<Cart> cartList = providerProdutService.selectByName1(pageStart, pageSize, servicename);
		long count = 0;
		if (servicename.equals("") || servicename == null)
			count = providerProdutService.getCount1();
		else
			count = providerProdutService.getCount1(servicename);
		map.put("cartList", cartList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		map.put("count", count);
//System.out.println("count="+count);
		return "e-commerce_shoping-car";
	}
	@RequestMapping("/deleteCartProdut")
	public String deleteCart(String id) {
		int i=providerProdutService.deleteByPrimaryKey(id);
		return i==1?"redirect:cartfenye":"error";
	}
	@ResponseBody
	@RequestMapping("/changeBuyNumCart")
	public Map<String, Object> changeCartNum(String productId,int buynum){
		System.out.println(productId);
		Map<String,Object> map = new HashMap<String,Object>();
		int unitPrice=providerProdutService.selectUnitPriceById(productId);
		int newTotalPrice = unitPrice*buynum;
		int oldTotalPrice = providerProdutService.selectTotalPriceById(productId);
		int code = providerProdutService.updateNumAndPriceByProductId(productId,buynum,newTotalPrice);
		int changePrice = newTotalPrice-oldTotalPrice;
		map.put("code", code);
		map.put("buynum", buynum);
		map.put("totalPrice", newTotalPrice);
		map.put("changePrice", changePrice);
		System.out.println(buynum + "-" + newTotalPrice + "-" + changePrice);
		return map;
	}
}
