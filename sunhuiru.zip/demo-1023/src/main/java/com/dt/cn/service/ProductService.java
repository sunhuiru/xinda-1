package com.dt.cn.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.dt.cn.model.User.ProviderProdut;



public interface ProductService {

	public long getCount();
	
	int getCount(@Param("servicename") String servicename);
	
	List<ProviderProdut> selectByName(int pageStart, int pageSize,String servicename);
	
	ProviderProdut selectByPrimaryKey(Integer id);
	
	int deleteByPrimaryKey(Integer id);
	
	int insert(ProviderProdut record);
	
	int updateByPrimaryKey(ProviderProdut record);

}
