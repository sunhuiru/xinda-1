package com.dt.cn.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dt.cn.model.User.BusinessOrder;
import com.dt.cn.model.User.XdUser;
import com.dt.cn.service.BusinessOrderService;
import com.dt.cn.service.xdUserService;

@Controller  //声明控制器
public class ControllerBusinessOrder {
	@Resource   //相当于创建对象
	BusinessOrderService businessOrderService;
	@Resource
	xdUserService xdUserService;
	@RequestMapping("/businessOrderfenye")
	public String businessOrderFenYe(Map<String,Object> map,
			@RequestParam(defaultValue="0")int pageStart,
			@RequestParam(defaultValue="4") Integer pageSize,
			@RequestParam(defaultValue="")String number) {
		List<BusinessOrder> businessOrderList=businessOrderService.selectByNumber(pageStart, pageSize, number);
		long count=0;
		if(number.equals("")||number==null) 
			count=businessOrderService.getCount();
		else 
			count=businessOrderService.getCount(number);
			map.put("businessOrderList",businessOrderList);
			map.put("pageStart", pageStart);
			map.put("pageSize", pageSize);
			map.put("number", number);
			map.put("count",count);
			return "operator_orderform";
		}
	
	  @RequestMapping("/XdUserfenye")
	public String XdUserFenYe(Map<String,Object>map,
	  
	  @RequestParam(defaultValue="0")int pageStart,
	  
	  @RequestParam(defaultValue="4") Integer pageSize,
	  
	  @RequestParam(defaultValue="")String name) { 
		List<XdUser> xduserList=xdUserService.selectByName(pageStart, pageSize, name); 
	  long count=0; 
	  if(name.equals("")||name==null) 
		  count=xdUserService.getCount();
	  else count=xdUserService.getCount(name);
	  map.put("xduserList",xduserList); map.put("pageStart", pageStart);
	  map.put("pageSize", pageSize); map.put("number", name);
	  map.put("count",count); return "operator_user"; }
	 
	
	@RequestMapping("/login")
	public String login() {
		return "e-commerce_login";
	}
	@RequestMapping("operator_orderform")
	public String logins1() {
		return "operator_orderform";
	}
	@RequestMapping("operator_user")
	public String logins2() {
		return "operator_user";
	}
	@RequestMapping("operator_facilitator")
	public String logins3() {
		return "operator_facilitator";
	}
	@RequestMapping("operator_expenses")
	public String logins4() {
		return "operator_expenses";
	}
	
	@RequestMapping("operator_recommend")
	public String logins5() {
		return "operator_recommend";
	}
	
	
	
	
	@RequestMapping("/delete1")
	public String deleteByPrimaryKey( String businessNo)
	{
	   int i=businessOrderService.deleteByPrimaryKey(businessNo);
	   System.out.println("i="+i);
	   if(i==1) {
		   return "redirect:businessOrderfenye";
	   }else {
		   return "error";
	   }
	   
	}
		            
	@RequestMapping("/logine")
	public String logine() {
		return "e-commerce_login";
	}
		
	}

