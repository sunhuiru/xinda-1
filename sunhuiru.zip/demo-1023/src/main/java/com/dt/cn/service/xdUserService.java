package com.dt.cn.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.dt.cn.model.User.XdUser;



public interface xdUserService {
	
	public List<XdUser> ope_login(String phone);
	
	public int ope_repassword(XdUser user);
	
	int insert(XdUser record);
	
	List<XdUser> selectByName(int pageStart ,int pageSize,String name);

	int getCount(@Param("name") String name);

   long getCount();
}
