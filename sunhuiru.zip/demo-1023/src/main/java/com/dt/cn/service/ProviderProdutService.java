package com.dt.cn.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import com.dt.cn.model.User.Cart;
import com.dt.cn.model.User.ProviderProdut;



public interface ProviderProdutService {
	List<ProviderProdut> selectByExample(int pageStart, int pageSize);

	public long getCount();

	int getCount(@Param("servicename") String servicename);

	List<ProviderProdut> selectByName(int pageStart, int pageSize, String servicename);

	int updataImg(ProviderProdut produt);

	ProviderProdut getProviderProdutById(String id);

	int insertSelective(Cart cart);

	ProviderProdut selectByPrimaryKey(String id);

	public long getCount1();

	int getCount1(@Param("servicename") String servicename);

	List<Cart> selectByName1(int pageStart, int pageSize, String servicename);

	int deleteByPrimaryKey(String id);

	int selectTotalPriceById(String productId);

	int updateNumAndPriceByProductId(String productId, int buynum, int totalprice);

	int selectUnitPriceById(String productId);
}
