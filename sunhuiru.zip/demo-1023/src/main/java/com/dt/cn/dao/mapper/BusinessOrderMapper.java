package com.dt.cn.dao.mapper;

import com.dt.cn.model.User.BusinessOrder;
import com.dt.cn.model.User.BusinessOrderExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
@Mapper 
public interface BusinessOrderMapper {


	long countByExample(BusinessOrderExample example);
	
	int deleteByPrimaryKey(String businessNo);

	int deleteByExample(BusinessOrderExample example);

	int insert(BusinessOrder record);

	int insertSelective(BusinessOrder record);

	List<BusinessOrder> selectByExample(BusinessOrderExample example);

	int updateByExampleSelective(@Param("record") BusinessOrder record, @Param("example") BusinessOrderExample example);

	int updateByExample(@Param("record") BusinessOrder record, @Param("example") BusinessOrderExample example);
     List<BusinessOrder> selectById(Integer id);
	
    int updateByPrimaryKeySelective(BusinessOrder record);

    int updateByPrimaryKey(BusinessOrder record);
    List<BusinessOrder> selectByNumber(int pageStart ,int pageSize,String number);

	int getCount(@Param("number") String number);

	List<BusinessOrder> selectByNumber(BusinessOrderExample businessorderExample);

	

	

	

	
}