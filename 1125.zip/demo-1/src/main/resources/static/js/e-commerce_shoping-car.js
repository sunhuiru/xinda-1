
$(function(){
    var name=sessionStorage.getItem("name");
    $(".name").text(name);
})

$(".search-product").on("click", function(){
    $(".search-product").addClass("font-aqua");
    $(".search-service").removeClass("font-aqua");
})
$(".search-service").on("click", function(){
    $(".search-service").addClass("font-aqua");
    $(".search-product").removeClass("font-aqua");
})

$(".banner a").on("click", function(event){
    $(".banner a").removeClass("border-b");
    $(event.target).addClass("border-b");
})

$(".content-nav li").on("click", function(event){
    $(".content-nav a").removeClass("nav-active");
    $(event.target).addClass("nav-active");
})
$(".search-btn").on("click", function(event){
    var servicename=$(".search input").val();
    location.href="cartfenye?servicename="+servicename;
})

	$(document)
			.ready(
					function() {
						var pcount = $('#count').val();
						var psize = $('#pageSize').val();
						var pstart = $('#pageStart').val();
						var servicename = $('#servicename').val();
						var nowpage = Math.floor(pstart / psize) + 1;
						var cpage = Math.ceil(pcount / psize);
						var strhtml = "";

						if (cpage <= 10) {
							for (var i = 1; i <= cpage; i++) {
								if (i == nowpage) {
									strhtml += '<a href=/cartfenye?pageStart='
											+ psize
											* (i - 1)
											+ '&servicename='
											+ servicename
											+ ' style="background-color:#aaaaaa;font-weight:700">'
											+ i + '</a>';
									//strhtml+='<a href=/userAll?pageStart='+psize*(i-1)+' style="background-color:#aaaaaa"><div class="nowpage">'+i+'</div></a>';
								} else {
									strhtml += '<span> <a href=/cartfenye?pageStart='
											+ psize
											* (i - 1)
											+ '&servicename='
											+ servicename
											+ '>'
											+ i
											+ '</a></span>';
								}
							}
						} else if (cpage > 10) {

							if (1 <= nowpage && nowpage <= 6) { //pagestart=20 nowpage=11 cpage=15

								for (var i = 1; i <= 10; i++) {

									if (i == nowpage) {
										strhtml += '<a href=/cartfenye?pageStart='
												+ psize
												* (i - 1)
												+ '&servicename='
												+ servicename
												+ ' style="background-color:#aaaaaa;font-weight:700">'
												+ i + '</a>';
										//strhtml+='<a href=/userAll?pageStart='+psize*(i-1)+' style="background-color:#aaaaaa"><div class="nowpage">'+i+'</div></a>';
									} else {
										strhtml += '<span> <a href=/cartfenye?pageStart='
												+ psize
												* (i - 1)
												+ '&servicename='
												+ servicename
												+ '>' + i + '</a></span>';
									}
								}
							} else if (nowpage <= cpage - 4) {

								for (var i = nowpage - 5; i <= nowpage + 4; i++) {//6--15			

									if (i == nowpage) {
										strhtml += '<a href=/cartfenye?pageStart='
												+ psize
												* (i - 1)
												+ '&servicename='
												+ servicename
												+ ' style="background-color:#aaaaaa;font-weight:700">'
												+ i + '</a>';
										//strhtml+='<a href=/userAll?pageStart='+psize*(i-1)+' style="background-color:#aaaaaa"><div class="nowpage">'+i+'</div></a>';
									} else {
										strhtml += '<span> <a href=/cartfenye?pageStart='
												+ psize
												* (i - 1)
												+ '&servicename='
												+ servicename
												+ '>' + i + '</a></span>';
									}

								}
							} else if (cpage - 4 < nowpage && nowpage <= cpage) {

								for (var i = cpage - 9; i <= cpage; i++) {

									if (i == nowpage) {
										strhtml += '<a href=/cartfenye?pageStart='
												+ psize
												* (i - 1)
												+ '&servicename='
												+ servicename
												+ ' style="background-color:#aaaaaa;font-weight:700">'
												+ i + '</a>';
										//strhtml+='<a href=/userAll?pageStart='+psize*(i-1)+' style="background-color:#aaaaaa"><div class="nowpage">'+i+'</div></a>';
									} else {
										strhtml += '<span> <a href=/cartfenye?pageStart='
												+ psize
												* (i - 1)
												+ '&servicename='
												+ servicename
												+ '>' + i + '</a></span>';
									}
								}
							} else {
								console.error(00000000);
							}
						} else {
							console.error(00000000);
						}
						$("#mydiv").html(strhtml);

					});
$(".subcart").on("click",function(){
	var productId = $(this).parent().parent().children().children(".productId").val();
	var getbuynum = $(this).siblings(".buynum");
	var buynum = getbuynum.val();
	var allPrice = $(".allPrice").text();
	var getTotalPrice = $(this).parent().parent().children().children(".totalPrice");
	if(buynum > 1){
		buynum--;
		$.ajax({
			url:"/changeBuyNumCart",
			type:"post",
			data:{
				"productId":productId,
				"buynum":buynum
			},
			dataType:"json",
			success:function(data){
				if(data.code == 1){
					//alert(data.buynum + "--" +data.totalPrice +"--" + (parseInt(allPrice)+data.changePrice))
					getbuynum.val(data.buynum);
					getTotalPrice.text(data.totalPrice);
					$(".allPrice").text(parseInt(allPrice)+data.changePrice);
				}else{
					alert("修改失败");
				}
				
			},
			error:function(){
				alert("操作失败");
			}
		});
	}else{
		location.href="#";
		alert("<=0");
	}
})

/**
 * 点击“+”时执行
 */
$(".addcart").on("click",function(){
	var productId = $(this).parent().parent().children().children(".productId").val();
	var getbuynum = $(this).siblings(".buynum");
	var buynum = getbuynum.val();
	var allPrice = $(".allPrice").text();
	var getTotalPrice = $(this).parent().parent().children().children(".totalPrice");
	if(buynum < 99){
		buynum++;
		$.ajax({
			url:"/changeBuyNumCart",
			type:"post",
			data:{
				"productId":productId,
				"buynum":buynum
			},
			dataType:"json",
			success:function(data){
				//alert("1111111");
				if(data.code == 1){
					//alert(data.buynum + "===" + data.totalPrice + "====" + allPrice);
					getbuynum.val(data.buynum);
					getTotalPrice.text(data.totalPrice);
					$(".allPrice").text(parseInt(allPrice)+data.changePrice);
				}else{
					alert("修改失败");
				}
				
			},
			error:function(){
				alert("操作失败");
			}
		});
	}else{
		location.href="#";
		alert("数量须小于等于99");
	}
})
/**
 * 输入数目时
 */
$(".buynum").change(function(){
	var productId = $(this).parent().parent().children().children(".productId").val();
	alert($(this).parent().parent().children().children(".productId").val());
	var buynum = $(this).val();
	var allPrice = $(".allPrice").text();
	var getTotalPrice = $(this).parent().parent().children().children(".totalPrice");
	$.ajax({
		url:"/changeBuyNumCart",
		type:"post",
		data:{
			"productId":productId,
			"buynum":buynum
		},
		dataType:"json",
		success:function(data){
			//alert("1111111");
			if(data.code == 1){
				//alert(data.buynum + "===" + data.totalPrice + "====" + allPrice);
				getTotalPrice.text(data.totalPrice);
				$(".allPrice").text(parseInt(allPrice)+data.changePrice);
			}else{
				alert("修改失败");
			}
			
		},
		error:function(){
			alert("操作失败");
		}
	});
})