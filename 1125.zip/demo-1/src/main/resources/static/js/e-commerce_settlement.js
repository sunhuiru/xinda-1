$(".payment li").eq(1).on("click", function(){
    location.href="e-commerce_order.html";
})
