package com.datangedu.cn.sercice;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.datangedu.cn.model.czy.Expenses;



public interface ExpensesService {
	List<Expenses> selectByNumber(int pageStart ,int pageSize,String number);

	int getCount(@Param("name") String number);

   long getCount();
}
