package com.datangedu.cn.sercice;

import java.util.List;

import org.springframework.expression.spel.ast.Operator;



public interface OperatorService {

	List<Operator> findBusiness();
	List<Operator> findUser1();
}
