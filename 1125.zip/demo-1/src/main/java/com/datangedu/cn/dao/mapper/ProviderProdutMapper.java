package com.datangedu.cn.dao.mapper;

import com.datangedu.cn.model.czy.ProviderProdut;
import com.datangedu.cn.model.czy.ProviderProdutExample;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ProviderProdutMapper {

	long countByExample(ProviderProdutExample example);

	int deleteByExample(ProviderProdutExample example);

	int deleteByPrimaryKey(Integer id);

	int insert(ProviderProdut record);

	int insertSelective(ProviderProdut record);

	List<ProviderProdut> selectByExample(ProviderProdutExample example);

	List<ProviderProdut> selectByExample(int pageStart, int pageSize);

	ProviderProdut selectByPrimaryKey(Integer id);

	int updateByExampleSelective(@Param("record") ProviderProdut record,
			@Param("example") ProviderProdutExample example);

	int updateByExample(@Param("record") ProviderProdut record, @Param("example") ProviderProdutExample example);

	int updateByPrimaryKeySelective(ProviderProdut record);

	int updateByPrimaryKey(ProviderProdut record);
	int updateById(ProviderProdut record);
	int getCount(@Param("servicename") String servicename);
	List<ProviderProdut> selectByName(int pageStart, int pageSize,String servicename);

	List<ProviderProdut> selectByName(ProviderProdutExample providerProdutExample);
	
	
	int insert5(ProviderProdut record);

    int insertSelective5(ProviderProdut record);

    int deleteByExample5(ProviderProdutExample example);

    int deleteByPrimaryKey5(Integer id);

    int updateByExampleSelective5(@Param("record") ProviderProdut record, @Param("example") ProviderProdutExample example);

    int updateByExampleWithBLOBs5(@Param("record") ProviderProdut record, @Param("example") ProviderProdutExample example);

    int updateByExample5(@Param("record") ProviderProdut record, @Param("example") ProviderProdutExample example);

    int updateByPrimaryKeySelective5(ProviderProdut record);

    int updateByPrimaryKeyWithBLOBs5(ProviderProdut record);
    
    int updateByPrimaryKey5(ProviderProdut record);

    List<ProviderProdut> selectByExampleWithBLOBs5(ProviderProdutExample example);

    List<ProviderProdut> selectByExample5(ProviderProdutExample example);

    ProviderProdut selectByPrimaryKey5(Integer id);

	List<ProviderProdut> selectByName5(int pageStart, int pageSize,String servicename);

	List<ProviderProdut> selectByName5(ProviderProdutExample providerProdutExample);
	
	long countByExample5(ProviderProdutExample example);
	
	int getCount5(@Param("servicename") String servicename);
}