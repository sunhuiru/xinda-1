package com.datangedu.cn.sercice.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.datangedu.cn.dao.mapper.BusinessOrderMapper;
import com.datangedu.cn.model.czy.BusinessOrder;
import com.datangedu.cn.model.czy.BusinessOrderExample;
import com.datangedu.cn.sercice.BusinessOrderService;



@Service  //声明服务层
public class BusinessOrderServiceImpl implements BusinessOrderService{
	@Resource //对象初始化一般在dao
	BusinessOrderMapper businessOrderMapper;
	@Override
	public BusinessOrder selectByPrimaryKey5(String businessNo) {
		// TODO Auto-generated method stub
		return businessOrderMapper.selectByPrimaryKey5(businessNo);
	}

	@Override
	public int getCount5(String ordername,String pId) {
		// TODO Auto-generated method stub
		return businessOrderMapper.getCount5(ordername, pId);
	}

	@Override
	public List<BusinessOrder> selectByName5(int pageStart, int pageSize, String ordername,String pId) {
		
		BusinessOrderExample businessOrderExample=new BusinessOrderExample();
		businessOrderExample.setDistinct(true);
		businessOrderExample.setPageSize(pageSize);
		businessOrderExample.setPageStart(pageStart);
		businessOrderExample.setOrdername(ordername);
		businessOrderExample.setpId(pId);
		
		return businessOrderMapper.selectByName5(businessOrderExample);
	}

	@Override
	public long getCount5(String pId) {
		BusinessOrderExample businessOrderExample=new BusinessOrderExample(); 
		return businessOrderMapper.countByExampleOrder5(pId);
	}
	@Override
	public List<BusinessOrder> selectByNumber(int pageStart, int pageSize, String number) {
		BusinessOrderExample  businessorderExample=new BusinessOrderExample();
		businessorderExample.setDistinct(true);
		businessorderExample.setPageStart(pageStart);
		businessorderExample.setPageSize(pageSize);
		businessorderExample.setNumber(number);
		return businessOrderMapper.selectByNumber(businessorderExample);
	}
		@Override
	public long getCount() {
			BusinessOrderExample  businessorderExample=new BusinessOrderExample();
		return businessOrderMapper.countByExample(businessorderExample);
	}
		@Override
		public int getCount(String number) {
			
			return  businessOrderMapper.getCount(number);
		}
		
	

	}


