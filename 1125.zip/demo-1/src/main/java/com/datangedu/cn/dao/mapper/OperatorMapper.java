package com.datangedu.cn.dao.mapper;



import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.expression.spel.ast.Operator;





@Mapper
public interface OperatorMapper {
	List<Operator> findBusiness();
	List<Operator> findUser1();
}
