package com.datangedu.cn.sercice;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.datangedu.cn.model.czy.BusinessOrder;

public interface BusinessOrderService {
	List<BusinessOrder> selectByNumber(int pageStart, int pageSize, String number);

	int getCount(@Param("number") String number);

	long getCount();

	BusinessOrder selectByPrimaryKey5(String businessNo);

	int getCount5(@Param("ordername") String ordername, @Param("pId") String pId);

	List<BusinessOrder> selectByName5(int pageStart, int pageSize, String ordername, String pId);

	public long getCount5(String pId);
}
