package com.datangedu.cn.dao.mapper;



import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.datangedu.cn.model.czy.Provider;
import com.datangedu.cn.model.czy.ProviderExample;
@Mapper
public interface ProviderMapper {
    long countByExample(ProviderExample example);

    int deleteByExample(ProviderExample example);

    int deleteByPrimaryKey(String id);

    int insert(Provider record);

    int insertSelective(Provider record);

    List<Provider> selectByExample(ProviderExample example);

    Provider selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") Provider record, @Param("example") ProviderExample example);

    int updateByExample(@Param("record") Provider record, @Param("example") ProviderExample example);

    int updateByPrimaryKeySelective(Provider record);

    int updateByPrimaryKey(Provider record);
    
    
    int getCount(@Param("name") String name);
    
    
    List<Provider> selectByName(int pageStart ,int pageSize,String name);
    List<Provider> selectByName(ProviderExample providerExample);
    
    
    long countByExample5(ProviderExample example);

    int deleteByExample5(ProviderExample example);

    int deleteByPrimaryKey5(String id);

    int insert5(Provider record);

    int insertSelective5(Provider record);

    List<Provider> selectByExample5(ProviderExample example);

    Provider selectByPrimaryKey5(String id);

    int updateByExampleSelective5(@Param("record") Provider record, @Param("example") ProviderExample example);

    int updateByExample5(@Param("record") Provider record, @Param("example") ProviderExample example);

    int updateByPrimaryKeySelective5(Provider record);

    int updateByPrimaryKey5(Provider record);
    
    int updateByPrimaryKeyStore5(Provider record);

    String getIdByCellPhone5(String cellphone);
    
    int saveUserImg5(Provider provider);
}