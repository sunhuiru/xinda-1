package com.datangedu.cn.dao.mapper;

import com.datangedu.cn.model.czy.Cart;
import com.datangedu.cn.model.czy.CartExample;
import com.datangedu.cn.model.czy.ProviderProdut;
import com.datangedu.cn.model.czy.ProviderProdutExample;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface CartMapper {
	long countByExample1(CartExample example);

	int deleteByExample(CartExample example);

	int deleteByPrimaryKey(Integer id);

	int insert(Cart record);

	int insertSelective(Cart record);

	List<Cart> selectByExample(CartExample example);

	Cart selectByPrimaryKey(Integer id);

	int updateByExampleSelective(@Param("record") Cart record, @Param("example") CartExample example);

	int updateByExample(@Param("record") Cart record, @Param("example") CartExample example);

	int updateByPrimaryKeySelective(Cart record);

	int updateByPrimaryKey(Cart record);

	int getCount1(@Param("servicename") String servicename);

	List<Cart> selectByName1(int pageStart, int pageSize, String servicename);

	List<Cart> selectByName1(CartExample cartExample);

	int selectTotalPriceById(Integer productId);

	int updateNumAndPriceByProductId(Integer productId, int buynum, int totalPrice);

	int selectUnitPriceById(Integer productId);
}