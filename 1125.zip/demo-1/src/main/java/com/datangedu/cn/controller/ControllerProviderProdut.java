package com.datangedu.cn.controller;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.datangedu.cn.model.czy.BusinessOrder;
import com.datangedu.cn.model.czy.Cart;
import com.datangedu.cn.model.czy.ProviderProdut;
import com.datangedu.cn.sercice.ProviderProdutService;


@Controller
public class ControllerProviderProdut {
	@Resource
	ProviderProdutService providerProdutService;
	@RequestMapping("/providerprodutfenye")
	public String providerProdutFenYe(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "1") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
		// System.out.println("aaaaaaaaaaaa");
		List<ProviderProdut> providerprodutList = providerProdutService.selectByName(pageStart, pageSize, servicename);
		long count = 0;
		if (servicename.equals("") || servicename == null)
			count = providerProdutService.getCount();
		else
			count = providerProdutService.getCount(servicename);
		map.put("providerprodutList", providerprodutList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		map.put("count", count);
		// System.out.println("count="+count);
		return "e-commerce_product";
	}

	@RequestMapping("/loadimg")
	public String loadImg() {
		return "upfile";
	}

	@RequestMapping("/upfile")
	public String saveUserImg(MultipartFile file, Integer id) {
		Map<Object, Object> result = new HashMap<Object, Object>();
		try {
			// 获取客户端传图图片的输入流
			InputStream ins = file.getInputStream();
			byte[] buffer = new byte[32768];// bit---byte---1k---1m
			int len = 0;
			// 字节输出流
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			while ((len = ins.read(buffer)) != -1) {
				bos.write(buffer, 0, len);
			}
			bos.flush();
			byte data[] = bos.toByteArray();
			System.out.println(data);
			ProviderProdut produt = new ProviderProdut();
			produt.setId(id);
			produt.setImg(data);
			providerProdutService.updataImg(produt);
			// System.out.println("aaaaaaaaaaaa");
			result.put("code", 1);
			result.put("msg", "保存头像成功");
		} catch (Exception e) {
			result.put("code", 0);
			result.put("msg", "保存头像失败");
			return "uploaderror";
		}
		return "index";
	}

	@RequestMapping(value = "/headImg", produces = MediaType.IMAGE_PNG_VALUE)
	public ResponseEntity<byte[]> headImg(Integer id) throws Exception {

		byte[] imageContent;
		ProviderProdut produt = providerProdutService.selectByPrimaryKey(id);
		imageContent = produt.getImg();
		// System.out.println("图片==="+produt.getImg());
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.IMAGE_PNG);
		return new ResponseEntity<byte[]>(imageContent, headers, HttpStatus.OK);
	}

	@RequestMapping("/insertCart")
	public String getById(Model model, @RequestParam(required = true) Integer id) {
		// System.out.println("id=:"+id);
		ProviderProdut providerProdut = providerProdutService.getProviderProdutById(id);
		// System.out.println(providerProdut.getId());
		model.addAttribute("providerProdut", providerProdut);
		Cart cart = new Cart();
		cart.setId(providerProdut.getId());
		cart.setProductId(providerProdut.getId());
		cart.setUnitPrice(providerProdut.getPrice());
		cart.setServiceName(providerProdut.getServiceName());
		cart.setImg(providerProdut.getImg());
		cart.setMemberId("22222");
		cart.setBuyNum(1);
		cart.setProvideId("111");
		cart.setServiceInfo("5555");
		cart.setServiceRequest("2222");
		cart.setTotalPrice(456);
		cart.setUnit("1");
		int code = providerProdutService.insertSelective(cart);
		// System.out.println("price="+providerProdut.getPrice());
		return code == 1 ? "redirect:cartfenye" : "error";
	}

	@RequestMapping("/cartfenye")
	public String cartFenYe(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "1") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
//System.out.println("aaaaaaaaaaaa");
		List<Cart> cartList = providerProdutService.selectByName1(pageStart, pageSize, servicename);
		long count = 0;
		if (servicename.equals("") || servicename == null)
			count = providerProdutService.getCount1();
		else
			count = providerProdutService.getCount1(servicename);
		map.put("cartList", cartList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		map.put("count", count);
//System.out.println("count="+count);
		return "e-commerce_shoping-car";
	}
	@RequestMapping("/deleteCartProdut")
	public String deleteCart(Integer id) {
		int i=providerProdutService.deleteByPrimaryKey(id);
		return i==1?"redirect:cartfenye":"error";
	}
	@ResponseBody
	@RequestMapping("/changeBuyNumCart")
	public Map<String, Object> changeCartNum(Integer productId,int buynum){
		System.out.println(productId);
		Map<String,Object> map = new HashMap<String,Object>();
		int unitPrice=providerProdutService.selectUnitPriceById(productId);
		int newTotalPrice = unitPrice*buynum;
		int oldTotalPrice = providerProdutService.selectTotalPriceById(productId);
		int code = providerProdutService.updateNumAndPriceByProductId(productId,buynum,newTotalPrice);
		int changePrice = newTotalPrice-oldTotalPrice;
		map.put("code", code);
		map.put("buynum", buynum);
		map.put("totalPrice", newTotalPrice);
		map.put("changePrice", changePrice);
		System.out.println(buynum + "-" + newTotalPrice + "-" + changePrice);
		return map;
	}
	@RequestMapping("/providerprodutfenye1")
	public String providerProdutFenYe1(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "1") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
		// System.out.println("aaaaaaaaaaaa");
		List<ProviderProdut> providerprodutList = providerProdutService.selectByName(pageStart, pageSize, servicename);
		long count = 0;
		if (servicename.equals("") || servicename == null)
			count = providerProdutService.getCount();
		else
			count = providerProdutService.getCount(servicename);
		map.put("providerprodutList", providerprodutList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		map.put("count", count);
		// System.out.println("count="+count);
		return "service_product";
	}
	
	
	@RequestMapping("/providerprodutfenye2")
	public String providerProdutFenYe5(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "4") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
		// System.out.println("aaaaaaaaaaaa");
		List<ProviderProdut> providerprodutList = providerProdutService.selectByName(pageStart, pageSize, servicename);
		long count = 0;
		if (servicename.equals("") || servicename == null)
			count = providerProdutService.getCount();
		else
			count = providerProdutService.getCount(servicename);
		map.put("providerprodutList", providerprodutList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		map.put("count", count);
		// System.out.println("count="+count);
		return "operator_product";
	}
	
	
	@RequestMapping("/deleteProviderProdut1")
	public String deleteProviderProdut1(Integer id) {
		int i=providerProdutService.deleteByPrimaryKey1(id);
		return i==1?"redirect:providerprodutfenye2":"error";
	}
	
	
	@RequestMapping("/updateQ2")
	public String updateQ2(Integer id, Model model) throws Exception {

		ProviderProdut providerprodutList = providerProdutService.selectByPrimaryKey(id);
		model.addAttribute("providerprodutList", providerprodutList);
		return "operator_update";
	}
	
	
	@RequestMapping("/update2")
	public String update12(ProviderProdut providerProdut) {
		int i = providerProdutService.updateByPrimaryKeySelective1(providerProdut);
		if (i == 1)
			return "redirect:/providerprodutfenye2";
		else
			return "error";

	}
	
	@RequestMapping("/deleteProviderProdut")
	public String deleteProviderProdut(Integer id) {
		int i=providerProdutService.deleteByPrimaryKey1(id);
		return i==1?"redirect:providerprodutfenye1":"error";
	}
	@RequestMapping("/insertProviderProdut")
	public String insertProviderProdut(ProviderProdut providerProdut) {
		int i=providerProdutService.insertSelective(providerProdut);
		return i==1?"redirect:providerprodutfenye1":"error";
	}
	
	@RequestMapping("/update")
	public String update1(ProviderProdut providerProdut) {
		int i = providerProdutService.updateByPrimaryKeySelective1(providerProdut);
		if (i == 1)
			return "redirect:/providerprodutfenye1";
		else
			return "error";

	}

	@RequestMapping("/updateQ")
	public String updateQ(Integer id, Model model) throws Exception {

		ProviderProdut providerprodutList = providerProdutService.selectByPrimaryKey(id);
		model.addAttribute("providerprodutList", providerprodutList);
		return "service_update";
	}

	@RequestMapping("/getBusinessOrser")
	public String getById1(Model model, @RequestParam(required = true) Integer id) {
		 System.out.println("id=:"+id);
		ProviderProdut providerProdut1 = providerProdutService.getProviderProdutById(id);
		 //System.out.println("111"+providerProdut.getServiceContent());
		model.addAttribute("providerProdut1", providerProdut1);
	     int machineId = 1;//最大支持1-9个集群机器部署
	        int hashCodeV = UUID.randomUUID().toString().hashCode();
	        if(hashCodeV < 0) {//有可能是负数
	            hashCodeV = - hashCodeV;
	        }
	        java.util.Date  date=new java.util.Date();
	        java.sql.Date  data1=new java.sql.Date(date.getTime());
     	BusinessOrder businessOrder = new BusinessOrder();
		businessOrder.setBusinessNo(machineId+ String.format("%015d", hashCodeV));
		businessOrder.setEvaluate(providerProdut1.getServiceContent());
		businessOrder.setOrderSum(providerProdut1.getPrice());
		businessOrder.setOrderInfo(providerProdut1.getServiceName());
		businessOrder.setCreateTime(data1);
		int code = providerProdutService.insertSelective1(businessOrder);
		// System.out.println("price="+providerProdut.getPrice());
		return code == 1 ? "redirect:orderfenye" : "error";
	}
	@RequestMapping("/orderfenye")
	public String orderFenYe(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "1") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
//System.out.println("aaaaaaaaaaaa");
		List<BusinessOrder> orderList = providerProdutService.selectByName2(pageStart, pageSize, servicename);
		long count = 0;
		if (servicename.equals("") || servicename == null)
			count = providerProdutService.getCount2();
		else
			count = providerProdutService.getCount2(servicename);
		map.put("orderList",orderList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		map.put("count", count);
//System.out.println("count="+count);
		return "e-commerce_order";
	}
	@RequestMapping("/orderfenye1")
	public String orderFenYe1(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "1") Integer pageSize, @RequestParam(defaultValue = "") String number) {
//System.out.println("aaaaaaaaaaaa");
		List<BusinessOrder> orderList = providerProdutService.selectByNumber(pageStart, pageSize, number);
		long count = 0;
		if (number.equals("") || number == null)
			count = providerProdutService.getCount2();
		else
			count = providerProdutService.getCount3(number);
		map.put("orderList",orderList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("number", number);
		map.put("count", count);
//System.out.println("count="+count);
		return "e-commerce_order";
	}
	@RequestMapping("/evaluatefenye")
	public String orderFenYe3(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "1") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
		List<BusinessOrder> orderList = providerProdutService.selectByName2(pageStart, pageSize, servicename);
		long count = 0;
		if (servicename.equals("") || servicename == null)
			count = providerProdutService.getCount2();
		else
			count = providerProdutService.getCount2(servicename);
		map.put("orderList",orderList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		map.put("count", count);
//System.out.println("count="+count);
		return "e-commerce_evaluate";
	}
	@RequestMapping("/evaluatefenye1")
	public String orderFenYe2(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "1") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
//System.out.println("aaaaaaaaaaaa");
		List<BusinessOrder> orderList = providerProdutService.selectByName2(pageStart, pageSize, servicename);
		long count = 0;
		if (servicename.equals("") || servicename == null)
			count = providerProdutService.getCount2();
		else
			count = providerProdutService.getCount2(servicename);
		map.put("orderList",orderList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		map.put("count", count);
//System.out.println("count="+count);
		return "e-commerce_evaluate2";
	}
	
	
	//@ResponseBody
	@RequestMapping("/updateevaluate")
	public String  updateQ1(String businessNo ,Model model) {		
		BusinessOrder evaluate = providerProdutService.selectByPrimaryKey1(businessNo);
		model.addAttribute("evaluate",evaluate);
		return "evaluate";
	}
	
	@RequestMapping("/updateevaluateQ")
	public String update1(BusinessOrder record) {		
		int i=providerProdutService.updateByPrimaryKeySelective(record);
		return i==1?"redirect:evaluatefenye1":"redirect:../error.html";
	}
	
	
	
	@RequestMapping("/deleteOrderProdut")
	public String deleteOrder(String businessNo) {
		int i=providerProdutService.deleteByPrimaryKey2(businessNo);
		return i==1?"redirect:orderfenye" : "error";
	}
	
	@RequestMapping("/loadimg1")
	public String loadImg1() {
		return "upfile1";
	}

	@RequestMapping("/upfile1")
	public String saveUserImg1(MultipartFile file) {
		Map<Object, Object> result = new HashMap<Object, Object>();
		try {
			// 获取客户端传图图片的输入流
			InputStream ins = file.getInputStream();
			byte[] buffer = new byte[32768];// bit---byte---1k---1m
			int len = 0;
			// 字节输出流
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			while ((len = ins.read(buffer)) != -1) {
				bos.write(buffer, 0, len);
			}
			bos.flush();
			byte data[] = bos.toByteArray();
			System.out.println(data);
			ProviderProdut produt = new ProviderProdut();
			produt.setId(00007);
			produt.setImg(data);
			providerProdutService.updataImg(produt);
			// System.out.println("aaaaaaaaaaaa");
			result.put("code", 1);
			result.put("msg", "保存头像成功");
		} catch (Exception e) {
			result.put("code", 0);
			result.put("msg", "保存头像失败");
			return "uploaderror";
		}
		return "redirect:providerprodutfenye";
	}
}
