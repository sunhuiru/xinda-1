package com.datangedu.cn.sercice.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.expression.spel.ast.Operator;
import org.springframework.stereotype.Service;

import com.datangedu.cn.dao.mapper.OperatorMapper;
import com.datangedu.cn.sercice.OperatorService;



@Service 
public class OperatorServiceImpl implements OperatorService{
	@Resource
	OperatorMapper operatorMapper;
	
	@Override
	public List<Operator> findBusiness() {
		
		return operatorMapper.findBusiness();

}

	@Override
	public List<Operator> findUser1() {
		
		return operatorMapper.findUser1();
	}}
