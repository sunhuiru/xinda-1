package com.datangedu.cn.sercice.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.datangedu.cn.dao.mapper.ProviderMapper;
import com.datangedu.cn.model.czy.Provider;
import com.datangedu.cn.model.czy.ProviderExample;
import com.datangedu.cn.sercice.ProviderService;


@Service  //声明服务层
public class ProviderServiceImpl implements ProviderService{
	@Resource //对象初始化一般在dao
	ProviderMapper providerMapper;
	@Resource
	ProviderService providerService;
	@Override
	public Provider selectByPrimaryKey5(String id) {
		ProviderExample providerExample = new ProviderExample();
		ProviderExample.Criteria criteria = providerExample.createCriteria();
		criteria.andIdEqualTo(id);		
		return providerMapper.selectByPrimaryKey5(id);
	}

	@Override
	public List<Provider> login5(String cellphone) {
		ProviderExample providerExample = new ProviderExample();
		ProviderExample.Criteria criteria = providerExample.createCriteria();
		criteria.andCellphoneEqualTo(cellphone);
		return providerMapper.selectByExample5(providerExample);
	}

	@Override
	public int insert5(Provider record) {
	

		return providerMapper.insert5(record);
	}

	@Override
	public int findpassword5(Provider provider) {
		// TODO Auto-generated method stub
		ProviderExample providerExample=new ProviderExample();
		return providerMapper.updateByExample5(provider, providerExample);
	}

	@Override
	public List<Provider> getProviderMessage5(String providerid) {
		ProviderExample providerExample = new ProviderExample();
		ProviderExample.Criteria criteria = providerExample.createCriteria();
		criteria.andIdEqualTo(providerid);
		return providerMapper.selectByExample5(providerExample);
	}

	@Override
	public List<Provider> getProviderStore5(String providerid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getIdByCellPhone5(String cellphone){
		return providerMapper.getIdByCellPhone5(cellphone);
	}

	@Override
	public int updateByPrimaryKey5(Provider record) {
		// TODO Auto-generated method stub
		return providerMapper.updateByPrimaryKey5(record);
	}

	@Override
	public Provider getUserInfo5(String id) {
		// TODO Auto-generated method stub
		return providerMapper.selectByPrimaryKey5(id);
	}

	@Override
	public void saveUserImg5(Provider provider) throws Exception {
		// TODO Auto-generated method stub
		int i =providerMapper.saveUserImg5(provider);
		if(i!=1) {
			throw new Exception("更新用户头像失败");
		}
	}

	@Override
	public int updateByPrimaryKeyStore5(Provider record) {
		// TODO Auto-generated method stub
		return providerMapper.updateByPrimaryKeyStore5(record);
	}
	@Override
	public List<Provider> selectByName(int pageStart, int pageSize, String name) {
		ProviderExample  providerExample=new ProviderExample();
		providerExample.setDistinct(true);
		providerExample.setPageStart(pageStart);
		providerExample.setPageSize(pageSize);
		providerExample.setName(name);
		return providerMapper.selectByName(providerExample);
	}
	@Override
	public long getCount() {
		ProviderExample  providerExample=new ProviderExample();
		return providerMapper.countByExample(providerExample);
	}
		@Override
		public int getCount(String name) {
			
			return  providerMapper.getCount(name);
		}
		
}
