package com.datangedu.cn.controller;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;


import com.datangedu.cn.dao.mapper.ProviderProdutMapper;
import com.datangedu.cn.model.czy.BusinessOrder;
import com.datangedu.cn.model.czy.Provider;
import com.datangedu.cn.model.czy.ProviderProdut;
import com.datangedu.cn.sercice.BusinessOrderService;
import com.datangedu.cn.sercice.ProviderProdutService;
import com.datangedu.cn.sercice.ProviderService;

@Controller
@RequestMapping
public class ControllerProvider {
	@Resource
	ProviderProdutService productService;
	@Resource
	BusinessOrderService orderService;
	@Resource
	ProviderService providerService;
	@Resource
	ProviderProdutMapper providerProdutMapper;
	@ResponseBody
    @RequestMapping(value = "/servicelogin", method = RequestMethod.POST)
    public Map<String, Object> login(String imgcode, String cellphone, String password, HttpServletRequest request) {
        HttpSession session = request.getSession();
        String code = (String) session.getAttribute("code");
        int code1 = 0;
        System.out.println("cellphone:" + cellphone + "  password:" + password + "  imgcode:" + imgcode);
        System.out.println("code:" + code);
        Map<String, Object> map = new HashMap<String, Object>();
        if (imgcode.toUpperCase().equals(code) && cellphone != null) {
            Provider provider = providerService.selectByPrimaryKey5(providerService.getIdByCellPhone5(cellphone));
            System.out.println(provider);
            if (provider.getPassword().equals(password)) {
                code1 = 1;
                map.put("code", code1);
                map.put("providerId", provider.getId());
                request.getSession().setAttribute("providerId", providerService.getIdByCellPhone5(cellphone));
                System.out.println(provider.getId());
            } else {
                map.put("code", code1);
            }
        } else {
            map.put("code", code1);
        }
        return map;
    }

    @ResponseBody
    @RequestMapping(value = "/serviceregister", method = RequestMethod.POST)
    public Map<String, Object> register(HttpServletRequest request) {
        HttpSession session = request.getSession();
        String code = (String) session.getAttribute("code");
        String imgcode = request.getParameter("imgcode");
        String id = request.getParameter("id");
        String cellphone = request.getParameter("cellphone");
        String password = request.getParameter("password");
        int code1 = 0;
        Map<String, Object> map = new HashMap<String, Object>();
        if (imgcode.toUpperCase().equals(code)) {
            Provider provider = new Provider();
            provider.setId(id);
            provider.setCellphone(cellphone);
            provider.setPassword(password);
            providerService.insert5(provider);
            code1 = 1;
            map.put("code", code1);
        } else {
            map.put("code", code1);
        }
        return map;
    }

    @ResponseBody
    @RequestMapping(value = "/servicefindpassword", method = RequestMethod.POST)
    public Map<String, Object> findpassword(HttpServletRequest request) {
        HttpSession session = request.getSession();
        String code = (String) session.getAttribute("code");
        String imgcode = request.getParameter("imgcode");
        String cellphone = request.getParameter("cellphone");
        int code1 = 0;
        Map<String, Object> map = new HashMap<String, Object>();
        if (imgcode.toUpperCase().equals(code)) {
            List<Provider> loginList = providerService.login5(cellphone);
            if (loginList != null && loginList.size() > 0) {
                Provider password = loginList.get(0);
                Provider provider = new Provider();
                provider.setId(password.getId());
                provider.setCellphone(password.getCellphone());
                provider.setPassword(request.getParameter("password"));
                if (request.getParameter("password").equals(request.getParameter("password1"))) {
                    providerService.findpassword5(provider);
                    code1 = 1;
                    map.put("code", code1);
                } else {
                    map.put("code", code1);
                }
            } else {
                map.put("code", code1);
            }
        }
        return map;
    }
    /*
	 * 根据服务商id获取服务商产品
	 */
	@ResponseBody
	@RequestMapping(value = "/providerprodutlistbyid", method = RequestMethod.GET)
	public Map<String, Object> providerProdutListById(HttpServletRequest request, String providerid) {
		System.out.println("providerProdutList start");

		HttpSession session = request.getSession();
		session.setAttribute("providerid", providerid);
		System.out.println(providerid);
		Map<String, Object> map = new HashMap<String, Object>();
		List<ProviderProdut> providerProdutList = productService.getProdutListById5(providerid);
		map.put("providerProdutList", providerProdutList);
		return map;
	}

	/*
	 * 产品上线下线
	 */
	@ResponseBody
	@RequestMapping(value = "providerprodutchange", method = RequestMethod.GET)
	public Map<String, Object> providerProdutChange(HttpServletRequest request, String id) {
		System.out.println("providerprodutchange start");
		Map<String, Object> map = new HashMap<String, Object>();
		List<ProviderProdut> providerProdutChangeList = productService.getProviderProdutChange5(id);
		System.out.println("大小：" + providerProdutChangeList.size());
		ProviderProdut providerProdut = new ProviderProdut();

		if (providerProdutChangeList.get(0).getStatus() == 1) {
			System.out.println("商品id1：" + providerProdutChangeList.get(0).getId());
			providerProdut.setId(providerProdutChangeList.get(0).getId());
			providerProdut.setStatus(2);
			System.out.println("商品id2：" + providerProdut.getId());
			System.out.println("商品状态： " + providerProdut.getStatus());
			providerProdutMapper.updateByPrimaryKeySelective5(providerProdut);
			map.put("mem", "修改状态成功");
			map.put("code", 1);
		} else {
			System.out.println("商品id1：" + providerProdutChangeList.get(0).getId());
			providerProdut.setId(providerProdutChangeList.get(0).getId());
			providerProdut.setStatus(1);
			System.out.println("商品id2：" + providerProdut.getId());
			System.out.println("商品状态： " + providerProdut.getStatus());
			providerProdutMapper.updateByPrimaryKeySelective5(providerProdut);
			map.put("mem", "修改状态成功");
			map.put("code", 1);
		}
		return map;
	}

	@RequestMapping("/serviceProduct")

	public String serviceProduct() {
		return "service_product";

	}

	@RequestMapping("/serviceExpenses")
	public String serviceExpenses() {

		return "service_expenses";

	}

	

	@RequestMapping("/selectByName")
	public String selectByExample(Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "3") Integer pageSize, @RequestParam(defaultValue = "") String servicename) {
		List<ProviderProdut> providerprodutList = productService.selectByName5(pageStart, pageSize, servicename);
		long count = 0;
		if ("".equals(servicename)) {
			count = productService.getCount5();
		} else {
			count = productService.getCount5(servicename);
		}
		map.put("count", count);
		map.put("providerprodutList", providerprodutList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("servicename", servicename);
		return "service_product";
	}

	@RequestMapping("/selectName")
	public String selectByName(HttpServletRequest request,Map<String, Object> map, @RequestParam(defaultValue = "0") int pageStart,
			@RequestParam(defaultValue = "4") Integer pageSize, @RequestParam(defaultValue = "") String ordername, @RequestParam(defaultValue = "") String pId) {
		String ppId=(String)request.getSession().getAttribute("providerId");
		List<BusinessOrder> businessorderList = orderService.selectByName5(pageStart, pageSize, ordername,ppId);
		long count = 0;
		System.out.println("pId="+ppId);
		if ("".equals(ordername)) {
			count = orderService.getCount(ppId);
			System.out.println("正常="+orderService.getCount(ppId));
		} else {
			count = orderService.getCount5(ordername,ppId);
			System.out.println("模糊="+orderService.getCount5(ordername,ppId));
		}
		map.put("count", count);
		map.put("businessorderList", businessorderList);
		map.put("pageStart", pageStart);
		map.put("pageSize", pageSize);
		map.put("ordername", ordername);
		map.put("pId", pId);
		
		return "service_orderform";
	}

	@RequestMapping("/delete5")
	public ModelAndView selectByExample(Map<String, Object> map,
			@RequestParam(defaultValue = "0", required = false) Integer id) {
		int i = productService.deleteByPrimaryKey5(id);
		if (i == 1) {
			return new ModelAndView("redirect:/selectByName");
		} else {
			return new ModelAndView("error");
		}
	}

	@RequestMapping("/insert5")
	public String insert(ProviderProdut providerProdut) {
		int i = productService.insert5(providerProdut);
		if (i == 1) {
			return "redirect:/selectByName";
		} else {
			return "error";
		}

	}

	@RequestMapping("/update5")
	public String update(ProviderProdut providerProdut) {
		int i = productService.updateByPrimaryKey5(providerProdut);
		if (i == 1) {
			return "redirect:/selectByName";
		} else {
			return "error";
		}

	}

	@RequestMapping("/updateQ5")
	public String updateQ(Integer id, Model model) throws Exception {

		ProviderProdut providerprodutList = productService.selectByPrimaryKey5(id);
		model.addAttribute("providerprodutList", providerprodutList);
		return "service_update";
	}

	@RequestMapping("/serviceSetting")
	public String selectByProvider(HttpServletRequest request, Model model) {
		String id = (String) request.getSession().getAttribute("providerId");
		Provider provider = providerService.selectByPrimaryKey5(id);
		if (provider == null) {
			System.out.println("provider is null");
			System.out.println("id:" + id);
		} else {
			System.out.println("provider:" + provider.toString());
		}
		model.addAttribute("provider", provider);
		return "service_setting";

	}
	/*
	 * @GetMapping("login5") public String login() { return "service_login"; }
	 */

	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) {
		request.getSession().removeAttribute("providerId");
		return "redirect:";
	}

	@RequestMapping("/redirect")
	public String jumpPage(HttpServletRequest request) {
		return request.getParameter("page");
	}
	//更改店铺信息
	/*
	 * @RequestMapping("/providerupdate") public String updateprovider(Provider
	 * provider) { int i = providerService.updateByPrimaryKey(provider);
	 * System.out.println("i="+i); if (i == 1) { return
	 * "redirect:/providerupdateQ?id="+provider.getId(); //获取修改id的值传给providerupdateQ
	 * } else { return "error"; }
	 * 
	 * }
	 */
//查询店铺信息
	@RequestMapping("/providerupdateQ")
	public String providerupdateQ(String id, Model model) throws Exception {
		Provider provider = providerService.selectByPrimaryKey5(id);
		model.addAttribute("provider", provider);
		return "service_setting";
	}

	//上传店铺头像
		@RequestMapping("/saveUserImg")
		public String saveUserImg(MultipartFile file,Provider provider) {
			Map<Object,Object> result = new HashMap<Object,Object>();

			try {
			// 获取客户端传图图片的输入流
			InputStream ins = file.getInputStream();
			byte[] buffer=new byte[4096];//bit---byte---1k---1m
			int len=0;
			 // 字节输出流
			 ByteArrayOutputStream bos=new ByteArrayOutputStream();
			while((len=ins.read(buffer))!=-1){
				bos.write(buffer,0,len);
			 }
			 bos.flush();
			byte data[] = bos.toByteArray();
			// 调用接口对图片进行存储
	
			 
			provider.setProviderImg(data);
			providerService.updateByPrimaryKey5(provider);
					            
			result.put("code",1);
				result.put("msg", "保存头像成功");
			} catch (Exception e) {
				result.put("code",0);
				result.put("msg", "保存头像失败");
				return "service_error";
			 }				
			return "redirect:/providerupdateQ?id="+provider.getId(); 	
		}
	//图片展示
		@RequestMapping(value = "/headImgSet", produces = MediaType.IMAGE_PNG_VALUE)
		public ResponseEntity<byte[]> headImg( String id) throws Exception{

			byte[] imageContent ;
			// 根据id获取当前用户的信息
			Provider provider = providerService.getUserInfo5(id);
					        
			imageContent = provider.getProviderImg();
			System.out.println("图片==="+provider.getProviderImg());
			// 设置http头部信息
			final HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.IMAGE_PNG);
			// 返回响应实体
			return new ResponseEntity<byte[]>(imageContent, headers, HttpStatus.OK);
		}
		
		//查询店铺信息
		@RequestMapping("/serviceStore")
		public String selectStore(HttpServletRequest request, Model model) {
			String id = (String) request.getSession().getAttribute("providerId");

			Provider provider = providerService.selectByPrimaryKey5(id);
			if (provider == null) {
				System.out.println("provider is null");
				System.out.println("id:" + id);
			} else {
				System.out.println("provider:" + provider.toString());
			}
			model.addAttribute("provider", provider);

			return "service_store";

		}
		
		//上传店铺营业执照
			@RequestMapping("/saveStoreImg")
			public String saveStoreImg(MultipartFile file,Provider provider) {
				Map<Object,Object> result = new HashMap<Object,Object>();
				try {
				// 获取客户端传图图片的输入流
				InputStream ins = file.getInputStream();
				byte[] buffer=new byte[4096];//bit---byte---1k---1m
				int len=0;
				 // 字节输出流
				 ByteArrayOutputStream bos=new ByteArrayOutputStream();
				while((len=ins.read(buffer))!=-1){
					bos.write(buffer,0,len);
				 }
				 bos.flush();
				byte data[] = bos.toByteArray();
				// 调用接口对图片进行存储
				
				provider.setImg(data);
				providerService.updateByPrimaryKeyStore5(provider);
						            
				result.put("code",1);
					result.put("msg", "保存头像成功");
				} catch (Exception e) {
					result.put("code",0);
					result.put("msg", "保存头像失败");
					return "service_error";
				 }				
				return "redirect:/serviceStore?id="+provider.getId();	
			}
			//营业执照展示
			@RequestMapping(value = "/storeImg", produces = MediaType.IMAGE_PNG_VALUE)
			public ResponseEntity<byte[]> storeImg( String id) throws Exception{

				byte[] imageContent ;
				// 根据id获取当前用户的信息
				Provider provider = providerService.getUserInfo5(id);
						        
				imageContent = provider.getImg();
				System.out.println("图片==="+provider.getImg());
						        
				// 设置http头部信息
				final HttpHeaders headers = new HttpHeaders();
				headers.setContentType(MediaType.IMAGE_PNG);
				// 返回响应实体
				return new ResponseEntity<byte[]>(imageContent, headers, HttpStatus.OK);
			}
		
			@RequestMapping("servicelogin1")
			public String logina() {
				return ("service_login");

			}


}
