package com.datangedu.cn.sercice;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.datangedu.cn.model.czy.Provider;

public interface ProviderService {
	List<Provider> selectByName(int pageStart, int pageSize, String name);

	int getCount(@Param("name") String name);

	long getCount();

	Provider selectByPrimaryKey5(String id);

	List<Provider> login5(String cellphone);

	int insert5(Provider provider);

	int findpassword5(Provider provider);

	List<Provider> getProviderMessage5(String providerid);

	List<Provider> getProviderStore5(String providerid);

	String getIdByCellPhone5(String cellphone);

	int updateByPrimaryKey5(Provider record);

	int updateByPrimaryKeyStore5(Provider record);

	public void saveUserImg5(Provider provider) throws Exception;

	Provider getUserInfo5(String id);
}
