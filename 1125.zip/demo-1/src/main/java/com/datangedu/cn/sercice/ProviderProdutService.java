package com.datangedu.cn.sercice;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import com.datangedu.cn.model.czy.BusinessOrder;
import com.datangedu.cn.model.czy.Cart;
import com.datangedu.cn.model.czy.ProviderProdut;
import com.datangedu.cn.model.czy.ProviderProdutExample;

public interface ProviderProdutService {
	List<ProviderProdut> selectByExample(int pageStart, int pageSize);

	public long getCount();

	int getCount(@Param("servicename") String servicename);

	List<ProviderProdut> selectByName(int pageStart, int pageSize, String servicename);

	int updataImg(ProviderProdut produt);

	ProviderProdut getProviderProdutById(Integer id);

	int insertSelective(Cart cart);

	ProviderProdut selectByPrimaryKey(Integer id);

	public long getCount1();

	int getCount1(@Param("servicename") String servicename);

	List<Cart> selectByName1(int pageStart, int pageSize, String servicename);

	int deleteByPrimaryKey(Integer id);

	int selectTotalPriceById(Integer productId);

	int updateNumAndPriceByProductId(Integer productId, int buynum, int totalprice);

	int selectUnitPriceById(Integer productId);

	int deleteByPrimaryKey1(Integer id);

	int insertSelective(ProviderProdut record);

	int updateByPrimaryKeySelective1(ProviderProdut record);

	int insertSelective1(BusinessOrder record);

	int getCount2(@Param("servicename") String servicename);

	List<BusinessOrder> selectByName2(int pageStart, int pageSize, String servicename);

	List<BusinessOrder> selectByNumber(int pageStart, int pageSize, String number);

	public long getCount2();

	int deleteByPrimaryKey2(String businessNo);

	int getCount3(@Param("number") String number);

	int updateByPrimaryKeySelective(BusinessOrder record);

	BusinessOrder selectByPrimaryKey1(String businessNo);

	public long getCount5();

	int getCount5(@Param("servicename") String servicename);

	List<ProviderProdut> selectByName5(int pageStart, int pageSize, String servicename);

	ProviderProdut selectByPrimaryKey5(Integer id);

	int deleteByPrimaryKey5(Integer id);

	int insert5(ProviderProdut record);

	int updateByPrimaryKey5(ProviderProdut record);

	List<ProviderProdut> getProdutListById5(String providerid);

	List<ProviderProdut> getProviderProdutChange5(String produtid);
}
