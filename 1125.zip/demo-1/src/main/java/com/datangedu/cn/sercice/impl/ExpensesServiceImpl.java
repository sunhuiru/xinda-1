package com.datangedu.cn.sercice.impl;

import java.util.List;


import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.datangedu.cn.dao.mapper.ExpensesMapper;
import com.datangedu.cn.model.czy.Expenses;
import com.datangedu.cn.model.czy.ExpensesExample;
import com.datangedu.cn.sercice.ExpensesService;



@Service  //声明服务层
public class ExpensesServiceImpl implements ExpensesService{
	@Resource //对象初始化一般在dao
	ExpensesMapper expensesMapper;
	@Override
	public List<Expenses> selectByNumber(int pageStart, int pageSize, String number) {
		ExpensesExample  expensesExample=new ExpensesExample();
		expensesExample.setDistinct(true);
		expensesExample.setPageStart(pageStart);
		expensesExample.setPageSize(pageSize);
		expensesExample.setNumber(number);
		return expensesMapper.selectByNumber(expensesExample);
	}
		@Override
	public long getCount() {
			ExpensesExample  expensesExample=new ExpensesExample();
		return expensesMapper.countByExample(expensesExample);
	}
		@Override
		public int getCount(String number) {
			
			return  expensesMapper.getCount(number);
		}
		
}
