package com.datangedu.cn.sercice.impl;


import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.datangedu.cn.dao.mapper.BusinessOrderMapper;
import com.datangedu.cn.dao.mapper.CartMapper;
import com.datangedu.cn.dao.mapper.ProviderMapper;
import com.datangedu.cn.dao.mapper.ProviderProdutMapper;
import com.datangedu.cn.model.czy.BusinessOrder;
import com.datangedu.cn.model.czy.BusinessOrderExample;
import com.datangedu.cn.model.czy.Cart;
import com.datangedu.cn.model.czy.CartExample;
import com.datangedu.cn.model.czy.ProviderProdut;
import com.datangedu.cn.model.czy.ProviderProdutExample;
import com.datangedu.cn.sercice.ProviderProdutService;
@Service
public class ProviderProdutServiceImpl implements ProviderProdutService{
	@Resource
    ProviderProdutMapper providerProdutMapper;
	@Resource
	CartMapper cartMapper;
	@Resource
	BusinessOrderMapper businessOrderMapper;
	@Resource
	ProviderMapper providerMapper;

	@Override
	public long getCount5() {
		ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		return providerProdutMapper.countByExample5(providerProdutExample);
	}

	@Override
	public int getCount5(String servicename) {
		return providerProdutMapper.getCount5(servicename);
	}

	@Override
	public List<ProviderProdut> selectByName5(int pageStart, int pageSize, String servicename) {
		ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		providerProdutExample.setDistinct(true);
		providerProdutExample.setPageStart(pageStart);
		providerProdutExample.setPageSize(pageSize);
		providerProdutExample.setServicename(servicename);
		return providerProdutMapper.selectByName5(providerProdutExample);
	}

	@Override
	public int deleteByPrimaryKey5(Integer id) {
		// TODO Auto-generated method stub
		return providerProdutMapper.deleteByPrimaryKey5(id);
	}

	@Override
	public int insert5(ProviderProdut record) {
		/* record.setId(12); */
		// TODO Auto-generated method stub
		return providerProdutMapper.insert5(record);
	}

	@Override
	public int updateByPrimaryKey5(ProviderProdut record) {
		// TODO Auto-generated method stub
		return providerProdutMapper.updateByPrimaryKey5(record);
	}

	@Override
	public ProviderProdut selectByPrimaryKey5(Integer id) {
		// TODO Auto-generated method stub
		return providerProdutMapper.selectByPrimaryKey5(id);
	}

	@Override
	public List<ProviderProdut> getProdutListById5(String providerid) {
		System.out.println("查询用户：" + providerid);
		ProviderProdutExample providerProdutExample = new ProviderProdutExample();
		ProviderProdutExample.Criteria criteria=providerProdutExample.createCriteria();
		criteria.andProviderIdEqualTo(providerid);
		return providerProdutMapper.selectByExample5(providerProdutExample);
	}

	@Override
	public List<ProviderProdut> getProviderProdutChange5(String id) {
		ProviderProdutExample providerProdutExample = new ProviderProdutExample();
		ProviderProdutExample.Criteria criteria=providerProdutExample.createCriteria();
		criteria.andIdEqualTo(id);
		System.out.println("查询商品id：" + id);
		return providerProdutMapper.selectByExample5(providerProdutExample);
	}
	@Override
	public List<ProviderProdut> selectByExample(int pageStart, int pageSize) {
		ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		providerProdutExample.setDistinct(true);
		providerProdutExample.setPageStart(pageStart);
		providerProdutExample.setPageSize(pageSize);
		//System.out.println("pageStart"+pageStart);
		return providerProdutMapper.selectByExample(providerProdutExample);
	}
	@Override
	public long getCount() {
		ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		return providerProdutMapper.countByExample(providerProdutExample);
	}
	@Override
	public int getCount(String servicename) {
		return providerProdutMapper.getCount(servicename);
	}
	@Override
	public List<ProviderProdut> selectByName(int pageStart, int pageSize, String servicename) {
		ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		providerProdutExample.setDistinct(true);
		providerProdutExample.setPageStart(pageStart);
		providerProdutExample.setPageSize(pageSize);
		providerProdutExample.setServicename(servicename);
		return providerProdutMapper.selectByName(providerProdutExample);
	}
	@Override                                   
	public int updataImg(ProviderProdut produt) {
		// TODO Auto-generated method stub
		return providerProdutMapper.updateById(produt);
	}
	@Override
	public int insertSelective(Cart record) {	
		//System.out.println("aaaaaaaaaaa"+record.getId());
		return cartMapper.insertSelective(record);
	}
	@Override
	public ProviderProdut getProviderProdutById(Integer id) {
		/*ProviderProdutExample providerProdutExample=new ProviderProdutExample();
		ProviderProdutExample.Criteria criteria=providerProdutExample.createCriteria();
		criteria.andIdEqualTo(id);
		return null;*/
		return providerProdutMapper.selectByPrimaryKey(id);
	}
	@Override
	public ProviderProdut selectByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		return providerProdutMapper.selectByPrimaryKey(id);
	}
	@Override
	public long getCount1() {
		CartExample cartExample=new CartExample();
		return cartMapper.countByExample1(cartExample);
	}
	@Override
	public int getCount1(String servicename) {
	
		return cartMapper.getCount1(servicename);
	}
	@Override
	public List<Cart> selectByName1(int pageStart, int pageSize, String servicename) {
		CartExample cartExample=new CartExample();
		cartExample.setDistinct(true);
		cartExample.setPageSize(pageSize);
		cartExample.setPageStart(pageStart);
		cartExample.setServicename(servicename);
		return cartMapper.selectByName1(cartExample);
	}
	@Override
	public int deleteByPrimaryKey(Integer id) {		
		return cartMapper.deleteByPrimaryKey(id);
	}
	@Override
	public int selectTotalPriceById(Integer productId) {
		// TODO Auto-generated method stub
		return cartMapper.selectTotalPriceById(productId);
	}
	@Override
	public int updateNumAndPriceByProductId(Integer productId,int buynum,int totalprice) {
		// TODO Auto-generated method stub
		return cartMapper.updateNumAndPriceByProductId(productId,buynum,totalprice);
	}
	@Override
	public int selectUnitPriceById(Integer productId) {
		// TODO Auto-generated method stub
		//System.out.println(productId);
		return cartMapper.selectUnitPriceById(productId);
	}
	@Override
	public int deleteByPrimaryKey1(Integer id) {
		// TODO Auto-generated method stub
		return providerProdutMapper.deleteByPrimaryKey(id);
	}
	@Override
	public int insertSelective(ProviderProdut record) {
		// TODO Auto-generated method stub
		return providerProdutMapper.insertSelective(record);
	}
	@Override
	public int updateByPrimaryKeySelective1(ProviderProdut record) {
		// TODO Auto-generated method stub
		return providerProdutMapper.updateByPrimaryKeySelective(record);
	}
	@Override
	public int insertSelective1(BusinessOrder record) {
		
		return businessOrderMapper.insertSelective(record);
	}
	@Override
	public int getCount2(String servicename) {
		// TODO Auto-generated method stub
		return businessOrderMapper.getCount2(servicename);
	}
	@Override
	public List<BusinessOrder> selectByName2(int pageStart, int pageSize, String servicename) {
		// TODO Auto-generated method stub
		BusinessOrderExample businessOrderExample=new BusinessOrderExample();
		businessOrderExample.setDistinct(true);
		businessOrderExample.setPageSize(pageSize);
		businessOrderExample.setPageStart(pageStart);
		businessOrderExample.setServicename(servicename);		
		return businessOrderMapper.selectByName2(businessOrderExample);
	}
	@Override
	public long getCount2() {
		BusinessOrderExample businessOrderExample=new BusinessOrderExample();
		return businessOrderMapper.countByExample(businessOrderExample);
	}
	@Override
	public int deleteByPrimaryKey2(String businessNo) {
		// TODO Auto-generated method stub
		return businessOrderMapper.deleteByPrimaryKey(businessNo);
	}
	@Override
	public List<BusinessOrder> selectByNumber(int pageStart, int pageSize, String number) {
		// TODO Auto-generated method stub
		BusinessOrderExample businessOrderExample=new BusinessOrderExample();
		businessOrderExample.setDistinct(true);
		businessOrderExample.setPageSize(pageSize);
		businessOrderExample.setPageStart(pageStart);
		businessOrderExample.setServicename(number);		
		return businessOrderMapper.selectByNumber(businessOrderExample);
	}
	@Override
	public int getCount3(String number) {
		
		return businessOrderMapper.getCount3(number);
	}
	
	@Override
	public int updateByPrimaryKeySelective(BusinessOrder record) {
		
		return businessOrderMapper.updateByPrimaryKeySelective(record);
	}
	@Override
	public BusinessOrder selectByPrimaryKey1(String businessNo) {
		
		return businessOrderMapper.selectByPrimaryKey(businessNo);
	}
}
