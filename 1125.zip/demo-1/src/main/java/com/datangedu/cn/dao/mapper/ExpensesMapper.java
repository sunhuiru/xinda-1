package com.datangedu.cn.dao.mapper;


import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.datangedu.cn.model.czy.Expenses;
import com.datangedu.cn.model.czy.ExpensesExample;
@Mapper 
public interface ExpensesMapper {
    long countByExample(ExpensesExample example);

    int deleteByExample(ExpensesExample example);

    int deleteByPrimaryKey(String name);

    int insert(Expenses record);

    int insertSelective(Expenses record);

    List<Expenses> selectByExample(ExpensesExample example);

    Expenses selectByPrimaryKey(String name);

    int updateByExampleSelective(@Param("record") Expenses record, @Param("example") ExpensesExample example);

    int updateByExample(@Param("record") Expenses record, @Param("example") ExpensesExample example);

    int updateByPrimaryKeySelective(Expenses record);

    int updateByPrimaryKey(Expenses record);
    
    
    int getCount(@Param("number") String number);
    List<Expenses> selectByNumber(int pageStart ,int pageSize,String number);


	List<Expenses> selectByNumber(ExpensesExample expensesExample);
}