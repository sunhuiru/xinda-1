package com.datangedu.cn.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.datangedu.cn.model.czy.XdUser;
import com.datangedu.cn.sercice.xdUserService;

@Controller
public class PublicController {
	@Resource
	xdUserService XdUserService;

	@ResponseBody
	@RequestMapping(value = "/log", method = RequestMethod.POST)
	public Map<String, Object> log(HttpServletRequest request) {
		System.out.println("000000000000");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("code", 1);
		return map;

	}

	@ResponseBody
	@RequestMapping(value = "/login")
	public Map<String, Object> login(HttpServletRequest request) {
		HttpSession session = request.getSession();
		String code = (String) session.getAttribute("code");
		String imgcode = request.getParameter("imgcode");
		System.out.println("getCommodity====" + request.getParameter("name"));
		System.out.println("getCommodity====" + request.getParameter("phone"));
		System.out.println("getCommodity====" + request.getParameter("password"));
		int code1 = 0;
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		Map<String, Object> map = new HashMap<String, Object>();
		System.out.println(imgcode + "=====" + code + "===");
		if (imgcode.toUpperCase().equals(code)) {
			List<XdUser> loginList = XdUserService.ope_login(phone);
			// List<XdUser> loginList1 = XdUserService.ope_login(name);
			XdUser password = loginList.get(0);
			if (password.getPassword().equals(request.getParameter("password"))) {
				code1 = 1;
				map.put("code", code1);
				map.put("name", password.getName());
				map.put("phone", password.getPhone());
			} else {
				map.put("code", code1);
			}
		} else {
			map.put("code", code1);
		}
		return map;
	}

	@ResponseBody
	@RequestMapping(value = "/repassword", method = RequestMethod.POST)
	public Map<String, Object> repassword(HttpServletRequest request) {
		HttpSession session = request.getSession();
		String code = (String) session.getAttribute("code");
		String imgcode = request.getParameter("imgcode");
		System.out.println("getCommodity====" + request.getParameter("phone"));
		String phone = request.getParameter("phone");

		int code1 = 0;
		Map<String, Object> map = new HashMap<String, Object>();
		if (imgcode.toUpperCase().equals(code)) {
			List<XdUser> loginList = XdUserService.ope_login(phone);
			XdUser xdUser = loginList.get(0);
			XdUser user = new XdUser();
			user.setId(xdUser.getId());
			user.setPhone(xdUser.getPhone());
			user.setPassword(request.getParameter("password"));
			user.setHeadImg(xdUser.getHeadImg());
			user.setEmail(xdUser.getEmail());
			user.setName(xdUser.getName());
			user.setStatus(xdUser.getStatus());
			user.setTs(xdUser.getTs());
			user.setCmbProvince(xdUser.getCmbProvince());
			user.setCmbCity(xdUser.getCmbCity());
			user.setCmbArea(xdUser.getCmbArea());
			if (request.getParameter("password").equals(request.getParameter("password1"))) {
				XdUserService.ope_repassword(user);
				code1 = 1;
				map.put("code", code1);
			} else {
				map.put("code", code1);
			}
		} else {
			map.put("code", code1);
		}
		System.out.println(imgcode + "=====" + code + "===");
		return map;
	}

	@ResponseBody
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public Map<String, Object> register(HttpServletRequest request) {
		System.out.println("11111111111");
		HttpSession session = request.getSession();
		String code = (String) session.getAttribute("code");
		String imgcode = request.getParameter("imgcode");
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String password = request.getParameter("password");
		String cmbProvince = request.getParameter("cmbProvince");
		String cmbCity = request.getParameter("cmbCity");
		String cmbArea = request.getParameter("cmbArea");
		int code1 = 0;
		Map<String, Object> map = new HashMap<String, Object>();
		if (imgcode.toUpperCase().equals(code)) {
			XdUser user = new XdUser();
			user.setId(id);
			user.setName(name);
			user.setPhone(phone);
			user.setPassword(password);
			user.setCmbProvince(cmbProvince);
			user.setCmbCity(cmbCity);
			user.setCmbArea(cmbArea);
			int i = XdUserService.insert(user);
			if (i == 1) {
				System.out.println("aaaaaaaaaaaaaa");
				code1 = 1;
				map.put("code", code1);
			}
		} else {
			map.put("code", code1);
		}
		System.out.println(imgcode + "=====" + code + "===");
		System.out.println(id + cmbProvince + password + phone + cmbCity + cmbArea + name);
		return map;
	}

	@ResponseBody
	@RequestMapping(value = "/register1", method = RequestMethod.POST)
	public Map<String, Object> register1(HttpServletRequest request) {
		System.out.println("11111111111");
		HttpSession session = request.getSession();
		String code = (String) session.getAttribute("code");
		String imgcode = request.getParameter("imgcode");
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String phone = request.getParameter("phone");
		String password = request.getParameter("password");
		String cmbProvince = request.getParameter("cmbProvince");
		String cmbCity = request.getParameter("cmbCity");
		String cmbArea = request.getParameter("cmbArea");
		int code1 = 0;
		Map<String, Object> map = new HashMap<String, Object>();
		if (imgcode.toUpperCase().equals(code)) {
			XdUser user = new XdUser();
			user.setId(id);
			user.setName(name);
			user.setPhone(phone);
			user.setPassword(password);
			user.setCmbProvince(cmbProvince);
			user.setCmbCity(cmbCity);
			user.setCmbArea(cmbArea);
			int i = XdUserService.insert(user);
			if (i == 1) {
				System.out.println("aaaaaaaaaaaaaa");
				code1 = 1;
				map.put("code", code1);
			}
		} else {
			map.put("code", code1);
		}
		System.out.println(imgcode + "=====" + code + "===");
		System.out.println(id + cmbProvince + password + phone + cmbCity + cmbArea + name);
		return map;
	}

	@RequestMapping("login1")
	public String login1() {
		return ("operator_login");

	}

	@RequestMapping("login2")
	public String login2() {
		return ("e-commerce_login");

	}

	@RequestMapping("qsl")
	public String aaa() {
		return ("redirect:providerprodutfenye1");

	}

	@RequestMapping("qsll")
	public String bbb() {
		return ("redirect:XdUserfenye");

	}

	@RequestMapping("qslll")
	public String ccc() {
		return ("redirect:providerprodutfenye");

	}


	@RequestMapping("cw1")
	public String ddd() {
		return ("operator_login");

	}

	@RequestMapping("cw2")
	public String fff() {
		return ("e-commerce_login");

	}


	@RequestMapping("ezccg")
	public String hhhhh() {
		return ("e-commerce_login");

	}

	@RequestMapping("ezc")
	public String hhhhhhh() {
		return ("e-commerce_register");

	}
	/*
	 * @RequestMapping("ezc") public String hhhhhhhh(){ return
	 * ("e-commerce_register ");
	 * 
	 * }
	 */

	@RequestMapping("ewjmm")
	public String hhhhhhhhhhhhh() {
		return ("e-commerce_findpassword");

	}

	@RequestMapping("owjmm")
	public String hhhhhhhhhhhhhh() {
		return ("operator_findpassword");

	}
}
