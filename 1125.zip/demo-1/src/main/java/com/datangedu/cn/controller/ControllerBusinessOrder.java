package com.datangedu.cn.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.expression.spel.ast.Operator;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.datangedu.cn.model.czy.*;
import com.datangedu.cn.model.czy.Expenses;
import com.datangedu.cn.model.czy.XdUser;
import com.datangedu.cn.sercice.*;
import com.datangedu.cn.sercice.ExpensesService;
import com.datangedu.cn.sercice.ProviderService;



@Controller  //声明控制器
public class ControllerBusinessOrder {
	@Resource   //相当于创建对象
	BusinessOrderService businessOrderService;
	@Resource
	xdUserService xdUserService;
	@Resource   
	ProviderService providerService;
	@Resource
	ExpensesService expensesService;
	
	
	
	@RequestMapping("/businessOrderfenye")
	public String BusinessOrderFenYe(Map<String,Object> map,
			@RequestParam(defaultValue="0")int pageStart,
			@RequestParam(defaultValue="4") Integer pageSize,
			@RequestParam(defaultValue="")String number) {
		List<BusinessOrder> businessOrderList=businessOrderService.selectByNumber(pageStart, pageSize, number);
		long count=0;
		if(number.equals("")||number==null) 
			count=businessOrderService.getCount();
		else 
			count=businessOrderService.getCount(number);

			map.put("businessOrderList",businessOrderList);
			map.put("pageStart", pageStart);
			map.put("pageSize", pageSize);
			map.put("number", number);
			map.put("count",count);
			return "operator_orderform";
		}
	
	
	
	
	
	
	  @RequestMapping("/XdUserfenye")
	public String XdUserFenYe(Map<String,Object>map,
	  
	  @RequestParam(defaultValue="0")int pageStart,
	  
	  @RequestParam(defaultValue="4") Integer pageSize,
	  
	  @RequestParam(defaultValue="")String name) { 
		List<XdUser> xduserList=xdUserService.selectByName(pageStart, pageSize, name); 
	  long count=0; 
	  if(name.equals("")||name==null) 
		  count=xdUserService.getCount();
	  else count=xdUserService.getCount(name);
	  map.put("xduserList",xduserList); map.put("pageStart", pageStart);
	  map.put("pageSize", pageSize); map.put("number", name);
	  map.put("count",count);
	  return "operator_user"; }
	 
	  
	  
	  
	  
	  
	  
	  @RequestMapping("/providerfenye") public String
	  ProviderFenYe(Map<String,Object>map,
	  
	  @RequestParam(defaultValue="0")int pageStart,
	  
	  @RequestParam(defaultValue="4") Integer pageSize,
	  
	  @RequestParam(defaultValue="")String name) {
		  List<Provider> providerList=providerService.selectByName(pageStart, pageSize, name); 
	  long count=0; 
	  if(name.equals("")||name==null) 
		  count=providerService.getCount();
	  else
		  count=providerService.getCount(name); 
	  map.put("providerList",providerList);
	  map.put("pageStart", pageStart); 
	  map.put("pageSize", pageSize);
	  map.put("number", name);
	  map.put("count",count);
	  return "operator_facilitator";
	  }
	  
	  @RequestMapping("/expensesfenye")
		public String expensesFenYe(Map<String,Object> map,
				@RequestParam(defaultValue="0")int pageStart,
				@RequestParam(defaultValue="4") Integer pageSize,
				@RequestParam(defaultValue="")String number) {
			List<Expenses> expensesList=expensesService.selectByNumber(pageStart, pageSize, number);
			long count=0;
			if(number.equals("")||number==null) 
				count=expensesService.getCount();
			else 
				count=expensesService.getCount(number);
			System.out.println("count="+count);
				map.put("expensesList",expensesList);
				map.put("pageStart", pageStart);
				map.put("pageSize", pageSize);
				map.put("number", number);
				map.put("count",count);
				return "operator_expenses";
			}
	  
	  
	
	@RequestMapping("operator_orderform")
	public String logins1() {
		return "operator_orderform";
	}
	@RequestMapping("operator_user")
	public String logins2() {
		return "operator_user";
	}
	@RequestMapping("operator_facilitator")
	public String logins3() {
		return "operator_facilitator";
	}
	@RequestMapping("operator_expenses")
	public String logins4() {
		return "operator_expenses";
	}
	
	@RequestMapping("operator_recommend")
	public String logins5() {
		return "operator_recommend";
	}
	
	
	
	}
	

