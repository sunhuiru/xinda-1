package com.datangedu.cn.sercice.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.datangedu.cn.dao.mapper.XdUserMapper;
import com.datangedu.cn.model.czy.XdUser;
import com.datangedu.cn.model.czy.XdUserExample;
import com.datangedu.cn.sercice.xdUserService;



@Service
public class xdUserServiceImpl implements xdUserService{
	@Resource
	XdUserMapper xdUserMapper;
	@Override
	public List<XdUser> ope_login(String phone) {
		XdUserExample xdUserExample=new XdUserExample();
		XdUserExample.Criteria criteria=xdUserExample.createCriteria();
		criteria.andPhoneEqualTo(phone);
		return xdUserMapper.selectByExample(xdUserExample);
	}
	@Override
	public int ope_repassword(XdUser user) {
		XdUserExample xdUserExample=new XdUserExample();
		XdUserExample.Criteria criteria=xdUserExample.createCriteria();
		return xdUserMapper.updateByExample(user, xdUserExample);
	}
	@Override
	public int insert(XdUser record) {
		return xdUserMapper.insert(record);
	}
	
	@Override
	public List<XdUser> selectByName(int pageStart, int pageSize, String name) {
		XdUserExample xdUserExample=new XdUserExample();
		xdUserExample.setDistinct(true);
		xdUserExample.setPageStart(pageStart);
		xdUserExample.setPageSize(pageSize);
		
		xdUserExample.setName(name);
		return xdUserMapper.selectByName(xdUserExample);
	}
    @Override
    
    
	public long getCount() {

		XdUserExample xdUserExample=new XdUserExample();
		return xdUserMapper.countByExample(xdUserExample);
	}
	
	@Override
	public int getCount(String name) {
		
		return xdUserMapper.getCount(name);
		
	}
}
