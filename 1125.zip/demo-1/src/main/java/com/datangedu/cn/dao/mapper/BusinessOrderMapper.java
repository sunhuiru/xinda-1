package com.datangedu.cn.dao.mapper;

import com.datangedu.cn.model.czy.BusinessOrder;
import com.datangedu.cn.model.czy.BusinessOrderExample;
import com.datangedu.cn.model.czy.Cart;
import com.datangedu.cn.model.czy.CartExample;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface BusinessOrderMapper {
	long countByExample(BusinessOrderExample example);

	int deleteByExample(BusinessOrderExample example);

	int deleteByPrimaryKey(String businessNo);

	int insert(BusinessOrder record);

	int insertSelective(BusinessOrder record);

	List<BusinessOrder> selectByExample(BusinessOrderExample example);

	BusinessOrder selectByPrimaryKey(String businessNo);

	int updateByExampleSelective(@Param("record") BusinessOrder record, @Param("example") BusinessOrderExample example);

	int updateByExample(@Param("record") BusinessOrder record, @Param("example") BusinessOrderExample example);

	int updateByPrimaryKeySelective(BusinessOrder record);

	int updateByPrimaryKey(BusinessOrder record);

	int getCount2(@Param("servicename") String servicename);

	int getCount3(@Param("number") String number);

	int getCount(@Param("number") String number);

	List<BusinessOrder> selectByName2(int pageStart, int pageSize, String servicename);

	List<BusinessOrder> selectByName2(BusinessOrderExample businessOrderExample);

	List<BusinessOrder> selectByNumber(int pageStart, int pageSize, String number);

	List<BusinessOrder> selectByNumber(BusinessOrderExample businessOrderExample);

	long countByExampleOrder5(String pId);

	BusinessOrder selectByPrimaryKey5(String businessNo);

	int getCount5(@Param("ordername") String ordername, @Param("pId") String pId);

	List<BusinessOrder> selectByName5(int pageStart, int pageSize, String ordername, String pId);

	List<BusinessOrder> selectByName5(BusinessOrderExample businessOrderExample);

	List<BusinessOrder> selectById5(String id);
}